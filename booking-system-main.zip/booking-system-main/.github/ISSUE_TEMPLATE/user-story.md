---
name: USER STORY
about: Default user story template
title: 'USER STORY:  <TITLE>'
labels: ''
assignees: ''

---

As a **role** I can **capability** so that **received benefit**.
